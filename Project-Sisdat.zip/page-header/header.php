<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="plugin/bootstrap5/css/bootstrap.min.css" rel="stylesheet">
<script src="plugin/bootstrap5/js/bootstrap.bundle.min.js"></script>

<link rel="stylesheet" type="text/css" href="Plugin/DataTables/datatables.min.css" />
<script type="text/javascript" src="Plugin/DataTables/datatables.min.js"></script>

<link rel="stylesheet" type="text/css" href="Plugin/DataTables/DataTables-1.12.1/css/jquery.dataTables.min.css" />
<link rel="stylesheet" type="text/css" href="Plugin/DataTables/Buttons-2.2.3/css/buttons.dataTables.min.css" />